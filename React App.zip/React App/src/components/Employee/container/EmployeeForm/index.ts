import EmployeeForm from './EmployeeForm'

export default EmployeeForm