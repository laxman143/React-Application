import Master from "./Master"

export default Master;