import { ReactNode } from "react";

export interface MasteProps {
    children: ReactNode
}