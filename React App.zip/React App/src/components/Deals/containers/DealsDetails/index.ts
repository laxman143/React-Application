import DealsDetails from "./DealsDetails";

export default DealsDetails