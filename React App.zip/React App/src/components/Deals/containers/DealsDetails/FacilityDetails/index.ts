import FacilityDetails from "./presentation/FacilityDetails";

export default FacilityDetails