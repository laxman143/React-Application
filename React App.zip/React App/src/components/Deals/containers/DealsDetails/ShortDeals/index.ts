import ShortDeals from "./presentation/ShortDetals";

export default ShortDeals