import Trades from "./presentation/Trade";

export default Trades