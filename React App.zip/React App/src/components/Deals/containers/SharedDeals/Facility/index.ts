import Facility from "./presentation/Facility";

export default Facility