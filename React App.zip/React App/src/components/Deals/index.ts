import Deals from "./Deals";

export default Deals