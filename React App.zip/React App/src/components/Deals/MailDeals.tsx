import React from 'react';
import DealsRouting from './DealsRouting';

class MainDeals extends React.Component<any, any> {

    constructor(props: any) {
        super(props);
       
    }

 
    render() {
        return <DealsRouting />
    }
}

export default MainDeals;
