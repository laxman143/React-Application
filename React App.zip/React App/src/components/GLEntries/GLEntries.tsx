import React from 'react';

class GLEntries extends React.Component<any,any> {
    constructor(props:any){
        super(props);
    }

    render() {
        return(<div>GLEntries</div>);
    }
}

export default GLEntries;