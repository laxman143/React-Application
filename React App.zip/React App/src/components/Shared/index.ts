import PrivateRoute from "./components/PrivateRoute";

export default PrivateRoute