

1) Login
2) user can not directly header secure page url , it will redirect to login page if without login hit url
3) refresh page maintains login state.
4) logout functionality
5) nested routing

For Start Json server

https://www.npmjs.com/package/json-server

json-server --watch deals.json --port 8000

----
For react Model
https://www.geeksforgeeks.org/how-to-open-or-close-react-bootstrap-modal-pro-grammatically/